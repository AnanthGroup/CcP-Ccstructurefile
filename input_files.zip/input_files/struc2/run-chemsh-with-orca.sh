#! /bin/bash
#SBATCH -J en2wt   
#SBATCH -t 700:00:00
#SBATCH -n 12
#SBATCH -N 1 
#SBATCH -p astra
#SBATCH -x c0055
#SBATCH -o chemsh-orca-%j.out

# Enter the working directory
cd ${SLURM_SUBMIT_DIR}

echo "starting $SLURM_JOB_ID at `date` on `hostname`"

echo "$USER"
MYTMP=/tmp/$USER/$SLURM_JOB_ID
/usr/bin/mkdir -p $MYTMP || exit $?
echo "Copying data over... "

##cp $SLURM_SUBMIT_DIR/inner_at $MYTMP
cp $SLURM_SUBMIT_DIR/qmatoms $MYTMP
cp $SLURM_SUBMIT_DIR/cm.psf $MYTMP
cp $SLURM_SUBMIT_DIR/save.chm $MYTMP
cp $SLURM_SUBMIT_DIR/active $MYTMP
cp $SLURM_SUBMIT_DIR/charmm.c $MYTMP
##cp $SLURM_SUBMIT_DIR/outer_at $MYTMP
cp $SLURM_SUBMIT_DIR/opt3.chm $MYTMP
cp $SLURM_SUBMIT_DIR/cm.pdb $MYTMP
cp $SLURM_SUBMIT_DIR/top_all22_heme.rtf $MYTMP
cp $SLURM_SUBMIT_DIR/par_mod.prm $MYTMP
cd $MYTMP

# Check that gnu8/8.3.0 and openmpi3/3.1.4 modules
# are already loading before submitting
module load chemsh-tcl-serial/3.7.1
module load orca/4.2.1
set -x

chemsh opt3.chm 
/usr/bin/mkdir $SLURM_SUBMIT_DIR/outputapr10
cd $SLURM_SUBMIT_DIR/outputapr10
cp $MYTMP/* .
rm -rf $MYTMP

exit 0

